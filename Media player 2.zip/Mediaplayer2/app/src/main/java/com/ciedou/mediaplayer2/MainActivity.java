package com.ciedou.mediaplayer2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.Display;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_READ = 0;

    /** Variables Globales **/
    MediaPlayer mediaPlayer;
    private static  final String TAG="Media Player";
    RecyclerView recyclerView;
    TextView tvSongTitle,tvCurrentPos,tvtotalDuration;
    SeekBar sbPosition;
    ImageView btnPrev,btnPlay,btnNxt;
    ArrayList<ModelSong> listSong;
    double currentPos,totalDuration;
    int audioIndex;




    public void init(){
        recyclerView=findViewById(R.id.recycleView);
        tvSongTitle=findViewById(R.id.tvSongTitle);
        tvCurrentPos=findViewById(R.id.tvCurrentPosition);
        tvtotalDuration=findViewById(R.id.tvTotalDuration);
        sbPosition=findViewById(R.id.sbPosition);
        btnPrev=findViewById(R.id.btnPrev);
        btnPlay=findViewById(R.id.btnPLay);
        btnNxt=findViewById(R.id.btnNext);



        mediaPlayer=new MediaPlayer();
        listSong=new ArrayList<ModelSong>();
        audioIndex=0;

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        if(checkPermission()){
            setSong();

        }

    }


    public boolean checkPermission() {
        int READ_CONTACTS = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
        if ((READ_CONTACTS != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_READ);
            return false;
        }
        return true;
    }




    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_READ: {
                if (grantResults.length > 0 && permissions[0].equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                    if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                        Toast.makeText(getApplicationContext(), "Please allow contact permission", Toast.LENGTH_LONG).show();
                    } else {
                        setSong();
                    }
                }
            }
        }
    }

    private void setSong() {
        init();
        getAudioFile();

        //gestion de la seekbar
        sbPosition.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {


            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            currentPos=seekBar.getProgress();
            mediaPlayer.seekTo((int)currentPos);
            }



        });

    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
        @Override
        public void onCompletion(MediaPlayer mediaPlayer) {
            audioIndex++;
            if(audioIndex<(listSong.size())){
                playSong(audioIndex);
            }else{
                audioIndex=0;
                playSong(audioIndex);
            }
        }
    });

if(!listSong.isEmpty()){
    playSong(audioIndex);
    prvSong();
    nxtSong();
    setPause();
}

    }

    private void playSong(int audioIndex) {
        try{
            mediaPlayer.reset();
            mediaPlayer.setDataSource(this,listSong.get(audioIndex).getSongUri());
            mediaPlayer.prepare();
            mediaPlayer.start();
            btnPlay.setImageResource(R.drawable.ic_baseline_pause_circle_filled_48_w);
            tvSongTitle.setText(listSong.get(audioIndex).getSongTitle());

            this.audioIndex=audioIndex;




            setSongProgress();








        }catch(Exception e){e.printStackTrace();}
    }





    public void prvSong(){
        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(audioIndex>0){
                    audioIndex--;
                }else{
                    audioIndex=listSong.size()-1;
                }
                playSong(audioIndex);
            }
        });


    }



    public void nxtSong(){
        btnNxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(audioIndex<(listSong.size()-1)){
                    audioIndex++;
                }else{
                    audioIndex=0;
                }
                playSong(audioIndex);
            }
        });
    }


    public void setPause(){
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mediaPlayer.isPlaying()){
                    mediaPlayer.pause();
                    btnPlay.setImageResource(R.drawable.ic_baseline_play_circle_filled_48_w);
                }else{
                    mediaPlayer.start();
                    btnPlay.setImageResource(R.drawable.ic_baseline_pause_circle_filled_48_w);
                }
            }
        });
    }


    public void setSongProgress(){
        currentPos=mediaPlayer.getCurrentPosition();
        totalDuration=mediaPlayer.getDuration();

        tvtotalDuration.setText(timeConvertion((long)totalDuration));
        tvCurrentPos.setText(timeConvertion((long)currentPos));

        sbPosition.setMax((int)totalDuration);


        final Handler handler=new Handler();

        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                try{
                    currentPos=mediaPlayer.getCurrentPosition();
                    tvCurrentPos.setText(timeConvertion((long)currentPos));
                    sbPosition.setProgress((int)currentPos);
                    handler.postDelayed(this,1000);
                }catch(IllegalStateException e){
                    e.printStackTrace();
                }
            }
        };
        handler.postDelayed(runnable,1000);
    }

    public String timeConvertion(long value){
        String songDuration;
        int dur=(int)value;
        int hrs=dur/3600000;
        int mns=dur/60000%600000;
        int scs=dur%60000/1000;

        if(hrs>0){
            songDuration=String.format("%02d:%02d:%02d",hrs,mns,scs);
        }else{
            songDuration=String.format("%02d:%02d",mns,scs);
        }

        return songDuration;

    }

    private void getAudioFile(){
        ContentResolver contentResolver=getContentResolver();
        Uri uri= MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;

        Cursor cursor=contentResolver.query(uri,null,null,null,null);


        if(cursor!=null&&cursor.moveToFirst()){
            do{
                String title=cursor.getString((int)cursor.getColumnIndex(MediaStore.Audio.Media.TITLE));
                String duration=cursor.getString((int)cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
                String artist=cursor.getString((int)cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
                String data=cursor.getString((int)cursor.getColumnIndex(MediaStore.Audio.Media.DATA));
                long albumId= cursor.getLong((int)cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID));

                Uri coverFolder=Uri.parse("content://media/external/audio/albumart");
                Uri albumArtUri= ContentUris.withAppendedId(coverFolder,albumId);
                ModelSong modelSong=new ModelSong();
                modelSong.setSongTitle(title);
                modelSong.setSongDuration(duration);
                modelSong.setSongArtiste(artist);
                modelSong.setSongUri(Uri.parse(data));
                modelSong.setSongCover(albumArtUri);
                listSong.add(modelSong);

            }while(cursor.moveToNext());

            AdapterSong adapterSong=new AdapterSong(this,listSong);
            recyclerView.setAdapter(adapterSong);
            adapterSong.setOnItemClickListener(new AdapterSong.OnItemClickListener() {
                @Override
                public void onItemClick(int pos, View v) {
                    playSong(pos);
                }
            });

        }


    }


}