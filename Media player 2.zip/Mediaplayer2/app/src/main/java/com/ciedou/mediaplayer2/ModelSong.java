package com.ciedou.mediaplayer2;

import android.net.Uri;

public class ModelSong {

    private String songTitle;
    private String songArtiste;
    private String songDuration;
    private Uri songUri;
    private Uri songCover;



    public Uri getSongCover() {
        return songCover;
    }

    public void setSongCover(Uri songCover) {
        this.songCover = songCover;
    }



    public ModelSong() {
    }

    public String getSongTitle() {
        return songTitle;
    }

    public void setSongTitle(String songTitle) {
        this.songTitle = songTitle;
    }

    public String getSongArtiste() {
        return songArtiste;
    }

    public void setSongArtiste(String songArtiste) {
        this.songArtiste = songArtiste;
    }

    public String getSongDuration() {
        return songDuration;
    }

    public void setSongDuration(String songDuration) {
        this.songDuration = songDuration;
    }

    public Uri getSongUri() {
        return songUri;
    }

    public void setSongUri(Uri songUri) {
        this.songUri = songUri;
    }
}
