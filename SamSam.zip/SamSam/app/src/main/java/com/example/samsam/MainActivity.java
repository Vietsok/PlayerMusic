package com.example.samsam;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.SeekBar;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Mainactivity";


    /* Var*/
    MediaPlayer mediaPlayer = new MediaPlayer();

    int state = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mediaPlayer = MediaPlayer.create(this, R.raw.sound);
        mediaPlayer.start();

// method call
position();
volume();

    }


    public void play(View view){
        mediaPlayer.start();

    }


    public void pause(View view){
        if( state == 0){
            mediaPlayer.pause();
            state = 1;
        }else{
            state = 0;
            mediaPlayer.start();
        }


    }


    public void position(){
// lien entre le desin et le code
        SeekBar sbPosition = findViewById(R.id.sbPosition);

        sbPosition.setMax(mediaPlayer.getDuration());

        sbPosition.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                Log.i(TAG,"Poisition dans le morceau:"+Integer.toString(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                pause(sbPosition);
                mediaPlayer.seekTo(sbPosition.getProgress());

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                play(sbPosition);
                mediaPlayer.seekTo(sbPosition.getProgress());

            }
        });


        // partie 2 deplacemnt automatique


        new Timer().scheduleAtFixedRate(new TimerTask(){
            @Override
            public void run(){
                sbPosition.setProgress(mediaPlayer.getCurrentPosition());
            }
        },0,300);

    }


public void volume(){
        SeekBar sbVolume = findViewById(R.id.sbVolume);

    AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

    int volumeMax = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
    sbVolume.setMax(volumeMax);

    int currentVolumpe = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC); // volume actuel du terminal
    sbVolume.setMax(currentVolumpe);


    sbVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress,0);
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    });




}

}