## Table de matières
1. [Introduction] (#Introduction)
2. [Lecture automatique] (#lecture-automatique)
3. [Création du plauer] (#creation-du-player)
4. [Autorisation et gestion du fichier manifest] (#autorisations)

### Introduction
****
sasasaassa
sasasaassasasass
assaasasas
